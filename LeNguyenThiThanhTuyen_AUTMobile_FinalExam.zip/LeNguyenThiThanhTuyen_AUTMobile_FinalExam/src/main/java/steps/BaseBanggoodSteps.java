package steps;

import core.KeywordAndroid;
import core.LogHelper;
import org.slf4j.Logger;
import org.testng.annotations.AfterClass;

public class BaseBanggoodSteps {
    protected KeywordAndroid mobile;
    public static Logger log = LogHelper.getLogger();

    public BaseBanggoodSteps(){
        this.mobile = new KeywordAndroid();
    }

    @AfterClass
    public void teardownTestSuite(){
        mobile.closeApplication();
    }
}
