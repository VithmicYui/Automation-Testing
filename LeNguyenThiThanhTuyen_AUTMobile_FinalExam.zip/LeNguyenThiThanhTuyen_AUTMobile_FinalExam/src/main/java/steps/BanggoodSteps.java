package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page.banggood.account.PageAccount;
import page.banggood.category.PageCategory;
import page.banggood.category.PageHomeDecor;
import page.banggood.category.PageRC;
import page.banggood.login.PageLoginBanggood;

public class BanggoodSteps extends BaseBanggoodSteps{
    PageCategory pageCategory = new PageCategory(mobile);
    PageHomeDecor pageHomeDecor = new PageHomeDecor(mobile);
    PageRC pageRC = new PageRC(mobile);
    PageAccount pageAccount = new PageAccount(mobile);
    PageLoginBanggood pageLoginBanggood = new PageLoginBanggood(mobile);
    String nameProduct = "";
    String name02 = "";
    String price02 = "";

    @Given("I open the Banggood Easy Online Shopping App")
    public void iOpenTheBanggoodEasyOnlineShoppingApp() {
        pageCategory.startBanggoodApp();
    }

    @Given("User is in Banggood Easy Home screen")
    public void userIsInBanggoodEasyHomeScreen() {
        pageCategory.verifyShowScreenBGHome();
    }

    @When("I click on the Category in the footer menu")
    public void iClickOnTheCategoryInTheFooterMenu() {
        pageCategory.goToCategory();
    }

    @And("I scroll and click on {string} in the left menu")
    public void iScrollAndClickOnInTheLeftMenu(String arg0) {
        pageCategory.goToHomeAndGarden();
    }

    @And("I click on {string} after the right category is displayed")
    public void iClickOnAfterTheRightCategoryIsDisplayed(String arg0) {
        pageHomeDecor.goToHomeDecor();
    }

    @And("I input price from {int} to {int} in the filter")
    public void iInputPriceFromToInTheFilter(int arg0, int arg1) {
        pageHomeDecor.inputPriceRange("20", "30");
    }

    @And("I click Done")
    public void iClickDone() {
        pageHomeDecor.clickToDone();
    }

    @And("I click on the first product")
    public void iClickOnTheFirstProduct() throws InterruptedException {
        pageHomeDecor.clickToProduct01();
    }

    @Then("the product name should be displayed")
    public void theProductNameShouldBeDisplayed() {
        nameProduct = mobile.getText(pageHomeDecor.TXT_NAME_PRODUCT_01);
        pageHomeDecor.verifyNameProductDisplayed(nameProduct);
    }

    @And("the product price should be in the range {int} to {int}")
    public void theProductPriceShouldBeInTheRangeTo(int arg0, int arg1) {
        String actualPrice = mobile.getText(pageHomeDecor.TXT_DETAIL_PRICE_PRODUCT);
        pageHomeDecor.verifyPriceProduct20To30(actualPrice);
    }

    @When("I scroll to {string} on the Home screen")
    public void iScrollToOnTheHomeScreen(String arg0) throws InterruptedException {
        pageCategory.scrollToHotCategory();
        pageCategory.goToTwoHotCategory();
    }

    @And("I click on the first category")
    public void iClickOnTheFirstCategory() {
        name02 = mobile.getText(pageHomeDecor.TXT_NAME_PRODUCT_02);
        price02 = mobile.getText(pageHomeDecor.TXT_PRICE_PRODUCT_02);
        pageRC.goToProduct02();
    }

    @And("the product detail page is displayed with name, price, Buy now, and Add to Cart buttons")
    public void theProductDetailPageIsDisplayedWithNamePriceBuyNowAndAddToCartButtons() throws InterruptedException {
        pageRC.verifyProduct02(name02, price02);
    }

    @And("I click {string} button")
    public void iClickButton(String arg0) {
        pageRC.clickToAddToCard();
    }

    @And("I click to {string} button again")
    public void iClickToButtonAgain(String arg0) {
        pageRC.clickToAddToCardAgain();
    }

    @And("I click the Cart icon on the footer")
    public void iClickTheCartIconOnTheFooter() {
        pageRC.clickIconCard();
    }

    @Then("the product name, size, price, and quantity should be displayed in the Cart")
    public void theProductNameSizePriceAndQuantityShouldBeDisplayedInTheCart() {
        pageRC.verifyProductInCard();
    }

    @When("I click on Account in the footer menu")
    public void iClickOnAccountInTheFooterMenu() {
        pageAccount.goToAccount();
    }

    @And("I click View All Order")
    public void iClickViewAllOrder() {
        pageAccount.clickToViewAllOrder();
    }

    @Then("the login screen should be displayed with Email, password, and SignIn button")
    public void theLoginScreenShouldBeDisplayedWithEmailPasswordAndSignInButton() {
        pageLoginBanggood.verifyShowScreenLogin();
    }
}
