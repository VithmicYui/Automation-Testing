package page.banggood;

import core.KeywordAndroid;
import core.LogHelper;
import org.openqa.selenium.By;
import org.slf4j.Logger;

public class BasePageBanggood {
    public static Logger log = LogHelper.getLogger();
    protected KeywordAndroid mobile;

    public By BTN_TRANG_CHU = By.xpath("//android.widget.TextView[@text=\"Home\"]");
    public By BTN_CATEGORY = By.xpath("//android.widget.TextView[@text=\"Category\"]");
    public By BTN_LAPTOP_MAY_TINH_LINH_KIEN = By.xpath("//android.widget.TextView[@text=\"Laptop - Máy Vi Tính - Linh kiện\"]");
    public By BTN_LAPTOP_COMPUTER = By.xpath("//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvTitle\" and @text=\"Laptop & Máy Vi Tính\"]");
    public By BTN_WHILE_USING_APP = By.xpath("//android.widget.Button[@text=\"WHILE USING THE APP\"]");
    public By BTN_HANG_QUOC_TE = By.xpath("//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\" and @text=\"Cross Border - Hàng Quốc Tế\"]");
    public BasePageBanggood(KeywordAndroid mobile) {
        this.mobile = mobile;
    }
    public By BTN_HOT_CATEGORY = By.xpath("//android.widget.TextView[@text=\"Hot Categories\"]");
    public By TXT_NAME_PRODUCT_02 = By.xpath("(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"])[2]");
    public By TXT_PRICE_PRODUCT_02 = By.xpath("(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"])[2]");
    public By BTN_TWO_HOT_CATEGORY = By.xpath("(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_title\"])[2]");
    public By ICON_ACCOUNT = By.xpath("//android.widget.TextView[@text=\"Account\"]");
    public void startBanggoodApp(){
        log.info("Log: Open Tiki App");
        mobile.startApplication("http://127.0.0.1:4723/", "platformName=android","platformVersion=11", "udid=192.168.225.103:5555"
                , "appPackage=com.banggood.client", "appActivity=com.banggood.client.module.home.MainActivity");
    }

    public void verifyShowScreenBGHome(){
        log.info("Verify show screen Banggood home");
        mobile.waitElementVisible(BTN_TRANG_CHU, 30);
        mobile.waitElementVisible(BTN_CATEGORY, 30);
    }
    public void goToCategory(){
        log.info("Go to Screen Category");
        mobile.tap(BTN_CATEGORY);
        verifyShowScreenCategory();
    }
    public void verifyShowScreenCategory(){
        log.info("Verify Show Screen Danh Muc");
        mobile.waitElementVisible(BTN_CATEGORY, 30);
    }
    public void scrollToHotCategory() throws InterruptedException {
        log.info("Log: Scroll to Hot Category");
        mobile.scrollDownToElement(BTN_HOT_CATEGORY);
        mobile.scrollDownToElement(BTN_TWO_HOT_CATEGORY);
    }
    public void goToTwoHotCategory(){
        log.info("Log: Go to Two Hot Category");
        mobile.tap(BTN_TWO_HOT_CATEGORY);
        verifyShowScreenTwoHotCategory();
    }
    public void goToProduct02(){
        log.info("Log: Go to Product 02");
        mobile.tap(TXT_NAME_PRODUCT_02);
    }
    public void verifyShowScreenTwoHotCategory(){
        log.info("Log: Verify show screen two Hot Category");
        mobile.waitElementVisible(TXT_NAME_PRODUCT_02, 30);
        mobile.waitElementVisible(TXT_PRICE_PRODUCT_02, 30);
    }
    public void goToAccount(){
        log.info("Log: Go to Account");
        mobile.tap(ICON_ACCOUNT);
    }
}
