package page.banggood.account;

import core.KeywordAndroid;
import core.LogHelper;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import page.banggood.BasePageBanggood;

public class PageAccount extends BasePageBanggood {
    public static Logger log = LogHelper.getLogger();
    public By BTN_VIEW_ALL_ORDER = By.xpath("//android.widget.TextView[@text=\"View All\"]");
    public PageAccount(KeywordAndroid mobile) {
        super(mobile);
    }
    public void clickToViewAllOrder(){
        log.info("Log: Click View All Order");
        mobile.waitElementVisible(BTN_VIEW_ALL_ORDER, 30);
        mobile.tap(BTN_VIEW_ALL_ORDER);
    }
}
