package page.banggood.category;

import core.KeywordAndroid;
import core.LogHelper;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import page.banggood.BasePageBanggood;

public class PageHomeDecor extends BasePageBanggood {
    public static Logger log = LogHelper.getLogger();
    public By BTN_HOME_DECOR = By.xpath("//android.widget.TextView[@text=\"Home Decor\"]");
    public By BTN_FILTER = By.xpath("//android.widget.TextView[@text=\"Filter\"]");
    public By TXT_INPUT_PRICE_MIN = By.xpath("//android.widget.EditText[@resource-id=\"com.banggood.client:id/edit_price_min\"]");
    public By TXT_INPUT_PRICE_MAX = By.xpath("//android.widget.EditText[@resource-id=\"com.banggood.client:id/edit_price_max\"]");
    public By BTN_DONE = By.xpath("//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_done\"]");
    public By TXT_NAME_PRODUCT_01 = By.xpath("(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"])[1]");
    public By TXT_PRICE_PRODUCT_01 = By.xpath("(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"])[1]");
    public By TXT_DETAIL_NAME_PRODUCT = By.xpath("//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"]");
    public By TXT_DETAIL_PRICE_PRODUCT = By.xpath("//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"]");

    public PageHomeDecor(KeywordAndroid mobile) {
        super(mobile);
    }
    public void goToHomeDecor(){
        log.info("Log: Go to Home Decor");
        mobile.tap(BTN_HOME_DECOR);
        verifyShowScreenHomeDecor();
    }
    public void verifyShowScreenHomeDecor(){
        log.info("Log: Verify show screen Home Decor");
        mobile.waitElementVisible(BTN_FILTER, 30);
    }
    public void inputPriceRange(String minPrice, String maxPrice) {
        log.info("Log: Input Price Range");
        mobile.tap(BTN_FILTER);
        mobile.setText(TXT_INPUT_PRICE_MIN, minPrice);
        mobile.setText(TXT_INPUT_PRICE_MAX, maxPrice);
    }
    public void clickToDone(){
        log.info("Log: Click to Done");
        mobile.tap(BTN_DONE);
    }
    public void clickToProduct01() throws InterruptedException {
        log.info("Log: Click to product first");
        Thread.sleep(1000);
        mobile.tap(TXT_NAME_PRODUCT_01);
        verifyShowScreenProduct01();
    }

    public void verifyShowScreenProduct01(){
        log.info("Log: Verify Show Screen Product");
        mobile.waitElementVisible(TXT_DETAIL_NAME_PRODUCT, 30);
        mobile.waitElementVisible(TXT_DETAIL_PRICE_PRODUCT, 30);
    }
    public void verifyNameProductDisplayed(String expectedName){
        String actualName = mobile.getText(TXT_DETAIL_NAME_PRODUCT);
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(actualName, expectedName.trim(), "Tên sản phẩm không khớp.");
        softAssert.assertAll();
    }
    public void verifyPriceProduct20To30(String actualPrice) {
//        actualPrice = actualPrice.replaceAll("[^\\d]", "");
        actualPrice = actualPrice.replaceAll("[^\\d]", "");
        try {
            double actualPriceValue = Double.parseDouble(actualPrice);
            Assert.assertTrue(actualPriceValue >= 410000 && actualPriceValue <= 1740000,
                    "Price should be in the range of 410,000 to 1,740,000. Actual price: " + actualPrice);
        } catch (NumberFormatException e) {
            System.out.println("Không thể chuyển đổi thành số: " + e.getMessage());
        }
    }
}
