package page.banggood.category;

import core.KeywordAndroid;
import core.LogHelper;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import page.banggood.BasePageBanggood;

public class PageCategory extends BasePageBanggood {
    public static Logger log = LogHelper.getLogger();

    public By BTN_HOME_GARDEN = By.xpath("//android.widget.TextView[@text=\"Home and Garden\"]");
    public By BTN_HOME_DECOR = By.xpath("//android.widget.TextView[@text=\"Home Decor\"]");

    public PageCategory(KeywordAndroid mobile) {
        super(mobile);
    }
    public void goToHomeAndGarden(){
        log.info("Log: Go to Home And Garden");
        mobile.tap(BTN_HOME_GARDEN);
        verifyShowScreenHomeAndGarden();
    }
    public void verifyShowScreenHomeAndGarden(){
        log.info("Lofg: Verify show screen Home And Garden");
        mobile.waitElementVisible(BTN_HOME_DECOR, 30);
    }

}
