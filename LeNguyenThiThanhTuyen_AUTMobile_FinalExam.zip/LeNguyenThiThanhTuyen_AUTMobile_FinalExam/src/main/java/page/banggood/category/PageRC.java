package page.banggood.category;

import core.KeywordAndroid;
import core.LogHelper;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.testng.asserts.SoftAssert;
import page.banggood.BasePageBanggood;
import page.banggood.category.PageHomeDecor;

public class PageRC extends BasePageBanggood {
    public static Logger log = LogHelper.getLogger();
    PageHomeDecor pageHomeDecor = new PageHomeDecor(mobile);
    public By BTN_BUY_NOW = By.xpath("//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_slide_buy\"]");
    public By BTN_ADD_TO_CARD = By.xpath("//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_slide_cart\"]");
    public By BTN_VERIFY_ADD_TO_CARD = By.xpath("//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_cart\"]");
    public By ICON_CARD = By.xpath("//android.widget.FrameLayout[@resource-id=\"com.banggood.client:id/cv_slide_cart\"]");
    public By TXT_NAME_IN_CARD = By.xpath("//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"]");
    public By TXT_PRICE_IN_CARD = By.xpath("//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"]");
    public By TXT_QUANTITY_IN_CARD = By.xpath("//android.widget.EditText[@resource-id=\"com.banggood.client:id/edit_qty\"]");
    public PageRC(KeywordAndroid mobile) {
        super(mobile);
    }
    public void verifyProduct02(String expectedName, String expectedPrice) throws InterruptedException {
        log.info("Log: Verify product 02");
        mobile.waitElementVisible(pageHomeDecor.TXT_DETAIL_NAME_PRODUCT, 30);
        mobile.waitElementVisible(pageHomeDecor.TXT_DETAIL_PRICE_PRODUCT, 30);
        mobile.waitElementVisible(BTN_ADD_TO_CARD, 30);
        mobile.waitElementVisible(BTN_BUY_NOW, 30);

        String actualName = mobile.getText(pageHomeDecor.TXT_DETAIL_NAME_PRODUCT);
        String actualPrice = mobile.getText(pageHomeDecor.TXT_DETAIL_PRICE_PRODUCT);

        SoftAssert softAssert = new SoftAssert();

        softAssert.assertEquals(actualName, expectedName.trim(), "Tên sản phẩm không khớp.");
        softAssert.assertEquals(actualPrice, expectedPrice, "Giá sản phẩm không khớp.");
        softAssert.assertAll();
        Thread.sleep(2000);
    }
    public void clickToAddToCard(){
        log.info("Log: Click to add to card");
        mobile.tap(BTN_ADD_TO_CARD);
        mobile.waitElementVisible(BTN_VERIFY_ADD_TO_CARD, 30);
    }
    public void clickToAddToCardAgain(){
        log.info("Log: Click to add to card agian");
        mobile.tap(BTN_VERIFY_ADD_TO_CARD);
        mobile.waitElementVisible(ICON_CARD, 30);
    }
    public void clickIconCard(){
        log.info("Log: Click icon Card");
        mobile.tap(ICON_CARD);
    }
    public void verifyProductInCard(){
        log.info("Log: Verify Product In Card");
        mobile.waitElementVisible(TXT_NAME_IN_CARD, 30);
        mobile.waitElementVisible(TXT_PRICE_IN_CARD, 30);
        mobile.waitElementVisible(TXT_QUANTITY_IN_CARD, 30);
    }

}
