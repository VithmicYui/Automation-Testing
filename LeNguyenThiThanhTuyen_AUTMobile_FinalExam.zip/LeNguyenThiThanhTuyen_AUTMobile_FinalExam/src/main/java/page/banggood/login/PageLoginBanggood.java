package page.banggood.login;

import core.KeywordAndroid;
import org.openqa.selenium.By;
import page.banggood.BasePageBanggood;

public class PageLoginBanggood extends BasePageBanggood {

    public By TXT_INPUT_EMAIL = By.xpath("//android.widget.EditText[@resource-id=\"com.banggood.client:id/et_email\"]");
    public By TXT_INPUT_PASSWORD = By.xpath("//android.widget.EditText[@resource-id=\"com.banggood.client:id/et_pwd\"]");
    public By BTN_SIGN_IN = By.xpath("//android.widget.Button[@resource-id=\"com.banggood.client:id/btn_sign\"]");
    public PageLoginBanggood(KeywordAndroid mobile) {
        super(mobile);
    }
    public void verifyShowScreenLogin(){
        log.info("Log: Verify show screen login");
        mobile.waitElementVisible(TXT_INPUT_EMAIL, 30);
        mobile.waitElementVisible(TXT_INPUT_PASSWORD, 30);
        mobile.waitElementVisible(BTN_SIGN_IN, 30);
    }
}
