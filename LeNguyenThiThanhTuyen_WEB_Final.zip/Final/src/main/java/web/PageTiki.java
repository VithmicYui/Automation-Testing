package web;

import core.KeywordWeb;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import untilitties.ExcelHandle;

import java.util.Random;

public class PageTiki {

    public By TB_SEARCH = By.xpath("//input[@type=\"text\"]");
    public By BTN_SEARCH = By.xpath("//button[contains(text(),'Tìm kiếm')]");
    public By IMG_CARD = By.xpath("(//div[@class='cart-wrapper'])[1]");
    public String ILM_PRODUCT_01 = "(//h3[normalize-space()='iPhone 15 Pro Max'])[1]";
    public By TITLE_PRODUCT_01 = By.xpath("(//h1[normalize-space()='Apple iPhone 15 Pro Max'])[1]");
    public By PRICE_PRODUCT_01 = By.xpath("//div[@class='styles__PriceStyled-sc-1vgh3o2-1 egMRnV']//div[1]");
    public By BTN_ADD_TO_CARD = By.xpath("(//button[contains(text(),'Thêm vào giỏ')])[1]");
    public By TBX_INPUT_PHONE = By.xpath("(//input[@placeholder='Số điện thoại'])[1]");
    public By BTN_GO = By.xpath("(//button[contains(text(),'Tiếp Tục')])[1]");
    public By TBX_INPUT_PASSWORD = By.xpath("(//input[@placeholder='Mật khẩu'])[1]");
    public By BTN_LOGIN = By.xpath("(//button[contains(text(),'Đăng Nhập')])[1]");
    public By MSG_ERROR = By.xpath("(//span[@class='error-mess'])[1]");
    public By BTN_RE_LOGIN = By.xpath("(//button[@class='btn-action'])[1]");
    public By BTN_CLOSE_LOGIN = By.xpath("(//img[@alt='icon'])[1]");
    Random random = new Random();
    int randomValue = random.nextInt(100) + 1;
    KeywordWeb webUI = new KeywordWeb();
    ExcelHandle excel = new ExcelHandle();
    private WebDriver driver;
    public PageTiki(WebDriver driver) {
        this.driver = driver;
    }


}
