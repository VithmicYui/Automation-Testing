package untilitties;

import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public class ExcelHandle {
    private FileInputStream fileIn;
    private FileOutputStream fileOut;
    private Workbook workbook;
    private Sheet sheet;
    private Cell cell;
    private Row row;
    private CellStyle cellStyle;
    private Color color;
    private String exelFilePath;
    private Map<String, Integer> columns = new HashMap<>();

    public void setExelFile(String exelPath, String sheetName) throws Exception {
        try {
            // khoi tao doi tuong excel file de nhan du lieu tu file theo duong dan da nhap
            File excelFile = new File(exelPath);
            // kiem tra neu duong dan khong dung (khong ton tai file) thi can tao file moi
            if (!excelFile.exists()) {
                excelFile.createNewFile();
                System.out.println("File does not exist, need to create an exel file.");
            }
            // doc du lieu tu file theo duong dan da nhap
            fileIn = new FileInputStream(exelPath);
            // luu du lieu doc duoc vao doi tuong workbook
            workbook = WorkbookFactory.create(fileIn);
            // khoi tao sheet tim theo ten sheet da nhap
            sheet = workbook.getSheet(sheetName);
            // kiem tra neu khong tim thay sheet thi tao sheet moi
            if (sheet == null) {
                sheet = workbook.createSheet(sheetName);
            }
            // return duong dan excel vao 1 bien
            this.exelFilePath = exelPath;
            // getRow(0): lay du lieu tu dong 1 cua file excel sheet
            // forEach(): duyet tung cell trong dong 1
            // (cell -> {}): tao doi tuong gom ten doi tuong = cell.getStringCellValue(); gia tri cua doi tuong = cell.getColumnIndex();
            //columns.put(); day tung doi tuong lay duoc tu cell vao doi tuong columns
            sheet.getRow(0).forEach(cell -> {
                columns.put(cell.getStringCellValue(), cell.getColumnIndex());
            });
        } catch (Exception e) {
            // neu gap cac loi nay thi throws ra Exception: sai duong dan excel path, noi dung file trong
            System.out.println(e.getMessage());
        }
    }

    public String getCellData(int rowNo, int colNo) {
        try {
            // khoi tao cell du lieu de chua du lieu tu 1 cell trong excel
            // getRow(): de lay du lieu ca 1 dong
            // getCell(): lay du lieu tung cot trong dong de lay duoc
            cell = sheet.getRow(rowNo).getCell(colNo);
            String cellData = null;
            // xu ly lay du lieu theo kieu du lieu cua cell
            switch (cell.getCellType()) {
                case STRING:
                    cellData = cell.getStringCellValue();
                    break;
                case NUMERIC:
                    // kiem tra neu du lieu trong cell la ngay thang thi dung getDateCellValue()
                    // cac truong hop numeric con lai thi dung getNumericCellValue()
                    if (DateUtil.isCellDateFormatted(cell)) {
                        cellData = String.valueOf(cell.getDateCellValue());
                    } else {
                        cellData = String.valueOf((long) cell.getNumericCellValue());
                    }
                    break;
                case BOOLEAN:
                    cellData = Boolean.toString(cell.getBooleanCellValue());
                    break;
                case BLANK:
                    cellData = "";
                    break;
            }
            return cellData;
        } catch (Exception e) {
            return "";
        }
    }

    public String getCell(String colName, int rowNo) throws Exception {
        //columns.get(colName): tra ve 1 ket qua int theo ten cot da nhap
        return getCellData(rowNo, columns.get(colName));
    }

    public void setCellData(String data, int rowNo, int colNo) throws Exception {
        try {
            // khoi tao dong chua du lieu
            row = sheet.getRow(rowNo);
            if (row == null) {
                row = sheet.createRow(rowNo);
            }
            // khoi tao cell chua du lieu
            cell = row.getCell(colNo);
            if (cell == null) {
                cell = row.createCell(colNo);
            }
            // ghi du lieu vao cell
            cell.setCellValue(data);
            // mo file can ghi theo duong dan
            fileOut = new FileOutputStream(exelFilePath);
            // ghi du lieu vao file
            workbook.write(fileOut);
            // luu file
            fileOut.flush();
            // dong file
            fileOut.close();
        } catch (Exception e) {
            throw (e);
        }
    }

}
