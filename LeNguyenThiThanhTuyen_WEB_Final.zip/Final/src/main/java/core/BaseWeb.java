package core;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseWeb {
    public KeywordWeb webUI;
    protected WebDriver driver; //khai bao object


    public BaseWeb(WebDriver driver) {
        this.driver = driver;
        webUI = new KeywordWeb();
    }

    @BeforeMethod
    public void beforeClass() throws InterruptedException {
        webUI.openBrowser("chrome", "https://tiki.vn/");
        driver = webUI.getDriver();
        driver.manage().window().maximize();
        System.out.println("Waiting for the browser to open...");
        Thread.sleep(3000);
    }

    @AfterMethod
    public void afterMethod() {
        webUI.closeBrowser();
    }
}
