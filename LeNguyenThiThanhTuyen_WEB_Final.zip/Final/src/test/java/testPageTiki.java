import core.KeywordWeb;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import untilitties.ExcelHandle;
import web.PageTiki;

public class testPageTiki {
    public PageTiki pageTiki;
    WebDriver driver;
    KeywordWeb webUI = new KeywordWeb();
    String browser = "chrome";
    ExcelHandle excel = new ExcelHandle();

    @BeforeMethod
    public void beforeClass() throws InterruptedException {
        driver = webUI.openBrowser(browser, "https://tiki.vn/");
        Thread.sleep(3000);
        pageTiki = new PageTiki(driver);
    }

    @Test
    public void testSearchProduct() throws Exception {
        excel.setExelFile("src/test/testData/TikiProduct.xlsx", "Sheet1");
        performProductSearchAndSelect();
        verifyProductInformation();
        performAddToCart();
        excel.setExelFile("src/test/testData/TikiLogin.xlsx", "Sheet1");
        performInvalidLoginWithPassword();
        verifyErrorMessageWithInvalidPassword();
        Thread.sleep(1000);
        performInvalidLoginWithoutPassword();
        Thread.sleep(1000);
        verifyErrorMessageWithoutPassword();
    }

    private void performProductSearchAndSelect() throws Exception {
        String searchName = excel.getCell("SEARCH", 1);
        webUI.setText(pageTiki.TB_SEARCH, searchName);
        webUI.clickElement(pageTiki.BTN_SEARCH);
        Thread.sleep(1000);
        webUI.clickElement(pageTiki.ILM_PRODUCT_01);
    }

    private void verifyProductInformation() throws Exception {
        String nameProduct = excel.getCell("NAME", 1);
        String priceProduct = excel.getCell("PRICE", 1);

        String actualNameProduct = webUI.getText(pageTiki.TITLE_PRODUCT_01);
        String actualPriceProduct = webUI.getText(pageTiki.PRICE_PRODUCT_01);

        Assert.assertEquals(actualNameProduct, nameProduct, "Tên sản phẩm không khớp.");
        Assert.assertEquals(actualPriceProduct, priceProduct, "Giá sản phẩm không khớp.");
    }

    private void performAddToCart() {
        webUI.clickElement(pageTiki.BTN_ADD_TO_CARD);
    }

    private void performInvalidLoginWithPassword() throws Exception {
        String phoneNumber = excel.getCell("PHONE", 1);
        String passwordLogin = excel.getCell("PASS", 1);

        webUI.setText(pageTiki.TBX_INPUT_PHONE, phoneNumber);
        webUI.clickElement(pageTiki.BTN_GO);
        webUI.setText(pageTiki.TBX_INPUT_PASSWORD, passwordLogin);
        webUI.clickElement(pageTiki.BTN_LOGIN);
    }

    private void verifyErrorMessageWithInvalidPassword() throws Exception {
        String errorMsg01 = excel.getCell("ERROR", 1);
        String actualErrorMessage01 = webUI.getText(pageTiki.MSG_ERROR);
        Assert.assertEquals(actualErrorMessage01, errorMsg01);
    }

    private void performInvalidLoginWithoutPassword() throws Exception {
        String phoneNumber = excel.getCell("PHONE", 1);
        webUI.clickElement(pageTiki.BTN_RE_LOGIN);
        webUI.setText(pageTiki.TBX_INPUT_PHONE, phoneNumber);
        webUI.clickElement(pageTiki.BTN_GO);
        webUI.clickElement(pageTiki.BTN_LOGIN);
    }

    private void verifyErrorMessageWithoutPassword() throws Exception {
        String errorMsg02 = excel.getCell("ERROR", 2);
        String actualErrorMessage02 = webUI.getText(pageTiki.MSG_ERROR);
        Assert.assertEquals(actualErrorMessage02, errorMsg02);
    }

}
